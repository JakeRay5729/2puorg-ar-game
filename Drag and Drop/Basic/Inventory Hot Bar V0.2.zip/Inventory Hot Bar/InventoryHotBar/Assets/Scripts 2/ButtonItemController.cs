using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ButtonItemController : MonoBehaviour
{
    public int ID;
    public int quantity;


    void Start()
    {

    }

}
